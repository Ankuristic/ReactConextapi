import { createContext } from "react";

export const colorContext= createContext();