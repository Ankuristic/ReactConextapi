import { createContext } from "react";

const totalContext = createContext();

export { totalContext };
