import { createContext } from "react";

const itemContext = createContext();

export { itemContext };