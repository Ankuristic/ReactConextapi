import ParentComponent from "./Components/ParentComponent";
import "./styles.css";

const App = () => {
  return <ParentComponent />;
};

export default App;
