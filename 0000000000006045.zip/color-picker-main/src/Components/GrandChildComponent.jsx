const GrandChildComponent = (props) => (
  <p style={{ color: props.color }}>Color: {props.color}</p>
);

export default GrandChildComponent;
